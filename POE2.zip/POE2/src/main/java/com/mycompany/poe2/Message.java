/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe2;

/**
 *
 * @author apple
 */
class Message {

    Message(int messageNumber, String string, String recipient) {
        
    }

   
        
    
}
