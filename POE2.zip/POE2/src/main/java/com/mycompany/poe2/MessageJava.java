/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe2;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author apple
 */
public class MessageJava {
    //declarations
    private String messageId;
    private int numMessageSent;
    private String recipient;
    private String message;
    private String messageHash;
    private static int totalMessageSent = 0;
    private static String sendMessage = ""; 
    private static String storedMessage = "";
    //Constructor
    public MessageJava() {
    this.messageId = generatedMessageId();
    
    this.messageHash = createMessageHash();
    
    this.message = message();
    
}
//method that generates a random message id
private String generatedMessageId() {
   String uniqueDigit = String.valueOf((long) (Math.random() * 1000000000L));
   while (uniqueDigit.length() < 9) {
       uniqueDigit = "0" + uniqueDigit;
   }
   String id = numMessageSent + uniqueDigit;
   return id.substring(0,10);
}
//method to check if message id is no more than 10 characters 
public boolean checkMessageId() {
    return messageId.length() <= 10;   
}
//method that checks recipient cell
public boolean recipientCell() {
    if (recipient.length() != 12) {
        return false;
    }
    if (!recipient.startsWith("+27")) {
        return false;
}
    for(int i = 3; i < recipient.length(); i++) {
        if (!Character.isDigit(recipient.charAt(i))) {
            return false;
    }

 }
   return true; 
} 
//Checks the cell phone number of the recipient
public String checkRecipientCell() {
    if (recipientCell()) {
        return "Cell phone number successfully captured. ";
    } 
    return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again ";
} 
//checks the length of a message 
public boolean messageLength() {
    return message.length() <= 250;
}
//Creates message hash
public String createMessageHash() {
    String makeMessage = " ";
    
    for (int i = 0; i < message.length(); i++) {
        char cCurrentChar = message.charAt(i);
        if (Character.isLetterOrDigit(cCurrentChar) || cCurrentChar == ' ') {
            makeMessage += cCurrentChar;
        }
    } makeMessage = makeMessage.trim();
    
    while (makeMessage.contains(" ")) {
        makeMessage = makeMessage.replace(" ", " ");
    }
    if(makeMessage.isEmpty()) {
        return messageId.substring(0,2) + ":" +numMessageSent + ":";
    }
    String firstWord;
    String lastWord; 
    int firstSpace = makeMessage.indexOf(" ");
    int lastSpace = makeMessage.indexOf(" ");
    
    if (firstSpace == -1) {
     firstWord = makeMessage.toUpperCase();
     lastWord = makeMessage.toUpperCase();
} else {
    firstWord = makeMessage.substring(0,firstSpace).toUpperCase();
    lastWord = makeMessage.substring(lastSpace + 1).toUpperCase();
 } return messageId.substring(0, 2) + ":" + numMessageSent + ":" + firstWord + lastWord;
}
 //send message method
 public String sendMessage() {
     Scanner myInput = new Scanner(System.in);
     
     int choice = myInput.nextInt();
  
     if (choice == 1) {
         totalMessageSent++;
        sendMessage += message() + "\n"; 
          return "Message successfully sent";
     }
     if (choice == 2) {
         return "Press 0 to delete the message.";
     }
     if(choice == 3) {
         storeMessage();
         return "Message successfully stored";
     }
     return "Invalid option";
 }
//Method to print all sent messages
 public String printMessages() {
     return sendMessage;
 }
 //Return total messages sent
 public static int returnTotalMessages() {
    return totalMessageSent ;
 }
 public void storeMessage() {
     String jsonMessage = "{"
             + "\"MessageID\":\"" + messageId + "\","
             + "\"MessageHash\":\"" + messageHash + "\","
             + "\"Recipient\":\"" + recipient + "\","
             + "\"Message\":\"" + message + "\"" + "}";
     
     if (storedMessage.isEmpty()) {
         storedMessage = jsonMessage;
     } else {
         storedMessage += ",\n" + jsonMessage;
     }
     try {
         FileWriter writing = new FileWriter("storedMessage.json");
         writing.write("[\n");
         writing .write(storedMessage);
         writing .write("\n]");
         writing .close();
     } catch (IOException e) {
         System.out.println("Error storing message.");
     }
 }
 //Prints messeges
 public String message() {
     return "Message ID: " + messageId
             + "\nMessage Hash: " + messageHash
             + "\nRecipient: " + recipient
             + "\nMessage: " + message;
 }


}