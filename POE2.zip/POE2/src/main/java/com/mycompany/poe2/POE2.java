/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe2;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.Arrays;
/**
 *
 * @author apple
 */
public class POE2 {

    
    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);
        Login myLog = new Login();
        
       //Declarations
       int choice;
       int messages = 0;
       int sendMessages = 0;
       int numMessages = 0;
     //login into the chatbox
     System.out.println("\nQuickChat");
     
     System.out.println("\nLogin");
     //promt the user to login
     System.out.print("Enter username");
     String usernameLogin = myInput.nextLine();
     System.out.print("Enter password ");
     String passwordLogin = myInput.nextLine();
     
     //
     System.out.println(myLog.returnLoginStatus(usernameLogin, passwordLogin));
    //if successful login  
    if (myLog.loginUser) {
    System.out.println("\nWelcome to QuickChat");
      
    System.out.print("How many messages would you like to send?");
    sendMessages = myInput.nextInt();
    
    //while statement
    while (true) {
        
        System.out.println("\n====MENU====");
        System.out.println("1. Send Messages");
        System.out.println("2. Show recently sent messages");
        System.out.println("3. Quit");
        //the 4th option 
        System.out.println("4. Stored Messages");
        //Prompt the user for a choice
        System.out.println("Choose an option(1 to 4)");
        choice = myInput.nextInt();
        
        //switch statement for choice 
        switch(choice) {
            case 1:
                int left = sendMessages - numMessages;
                if(left <= 0) {
                    System.out.println("You have already entered all" + sendMessages + "messages.");
                break;
                }
                for(int i = 0; i < left;i++) {
                    sendMessagers();
                    sendMessages++;
                }
            case 2:
                System.out.println("Coming soon. ");
                break;
            case 3:
                System.out.println("Goodbye. ");
                //4th case for part 3
            case 4: 
                System.out.println("1. Display stored Messages");
                System.out.println("2. Longest Message");
                System.out.println("3. Search Message ID");
                System.out.println("4. Search recipient ");
                System.out.println("5. Delete message Hash");
                System.out.println("6. Display a report");
                int c = myInput.nextInt();
                
                //switch statement for c
                switch(c) {
                    case 1:
                        if(storedCount == 0) {
                            System.out.println("No Stored Messages");
                            return;
                        }
                        for (int i = 0; i < storedCount; i++) {
                            System.out.println(storedMessages[i]);
                        } break;
                    case 2:
                        
                        String longMessage = storedMessage.get(0);//
                        //for loop
                        for(String messagesM: storedMessages){
                            if(messagesM.getMessage().length() > longest.getMessage().length){
                                longest = messagesM;
                            }
                        }
                        System.out.println("Longest message: ");
                            System.out.println(longest.getMessage);
                        
                        break;
                    case 3://option 3(Searching messageID)
                        System.out.print("Enter the message ID you are seacrhing for ");
                        int searchId = myInput.nextInt();
                        //for loop
                        for(String messagesM: storedMessages){
                            if(messagesM.getMessageId().equals(searchId)){
                                System.out.println("Recipient: " + messagesM.getRecipient());
                                System.out.println("Message: " + messagesM.getMessage());
                                return;
                            } System.out.println("Message ID not found");
                        
                            } break;
                            
                    case 4://option 4(Searching recipient)
                        System.out.println("Enter the recipient you are searching for ");
                        String searcgRecipi = myInput.nextLine();
                        //boolean expression
                        boolean recipiFound = false;
                        
                        for(String messagesM: storedMessages){
                            if(messagesM.getRecipient().equalsIgnoreCase(recipient)){
                                System.out.println(messagesM.getMessage());
                                recipiFound = true;
                            } if(!recipiFound){
                                System.out.println("The searched Recipient is not found");
                            } break;
                        }
                    case 5:
                       System.out.println("Enter message Hash");
                        String mHash =myInput.nextLine();
                        //for loop
                        for(int i = 0; i < storedMessage.size(); i++){
                            if(storedMessage.get(i).getMessageHash().equals(mHash)){
                                storedMessage.remove(i);
                                System.out.println("Message deleted");
                            }return;
                        } System.out.println("Message Hash not found");
                        break;
                        
                    case 6:
                        System.out.println("\nMessage Report");
                        //for loop
                        for(String messagesM: storedMessages){
                           System.out.println("Message ID: " + messagesM.getMessageId());
                           System.out.println("Message Hash: " + messagesM.getMessageHash());
                           System.out.println("Recipient: " + messagesM.getRecipient());
                           System.out.println("Message: " + messagesM.getMessage());
                        }
                        
            }
                        
                }
            default:
                System.out.println("Invalid Option. Please choose option 1,2,3 or 4.");
        }
    }
  }
    

    public static void sendMessagers() {
        Scanner myInput = new Scanner(System.in);
        int messageNumber = 0;
        System.out.println("\n--- New Message (#" + messageNumber + ") ----");
        String recipient;
        while(true) {
            System.out.print("Enter recipient cell phone number");
            recipient = myInput.nextLine();
            Message mS = new Message(messageNumber, "0000000000",recipient);
            String result = mS.checkRecipientCell();
            
            System.out.println(result);
            if (result.equals("Cell phone number successfully captured.")) {
                break;
            }
        }
        String messageChat;
        while(true) {
            System.out.println("Enter your message");
            messageChat = myInput.nextLine();
            Message mS = new Message(messageNumber, "0000000000", recipient);
            String result = mS.messageLength();
            
            System.out.println(result);
            if (result.equals("Message ready to send")) {
                break;
            }
        }
        Message mm = new Message(messageNumber, recipient, messageChat);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message");
        System.out.println("Choose an option");
        int choice = myInput.nextInt();
       System.out.println(mm.sendMessage());
       
}
//PART 3
    public void readeringJson(){
     Gson gs = new Gson();
    //try
    try(BufferedReader bb = new BufferedReader(new FileReader("storedMessage.json"))) {
    String[] storedMessages = gs.fromJson(bb, String[].class);
    //for loop
    for (String messagesM: storedMessages) {
       storedMessages[storedCount] = messagesM;
       storedCount++;
    } //reference
} catch(IOException e){
   e.printStackTrace();
}
}

    //the arrays 
  public static String[] sentMessage = new String[100]; 
  private static String[] discardMessages = new String[100];
  private static String[] storedMessages = new String[100];
  private static String[] messagesHash = new String[100];
  private static String[] messageId = new String[100];
  private static int storedCount = 0;
  private static int discardCount = 0;
  private static int sentCount = 0;
  private static int idCount = 0;
  private static int hashCount = 0;
  
  
}